javac *.java
java TSP <test
